#!/bin/bash

ruby1.9.3 lang0.tab.rb
