csci-498-compilers - DECAFBEEF
==================


repository for csci 498 compiler design

Requirements
-------
    - Ruby version 2.1.0 (older versions might work)
    - rexical gem
    - racc gem
    
Usage
------
to build:

./build_alamode

make

to run:
./run_alamode <stdin>
